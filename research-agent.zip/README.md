# Research Agent

A small, configurable research agent based on the supplied Colab workshop. It uses Groq models with tool calling, Tavily for web search, ArXiv and Wikipedia for specialist references, and a URL reader to inspect pages returned by search.

## Models

Set `GROQ_MODEL` to select a model:

| Model | Role |
|---|---|
| `openai/gpt-oss-120b` | Original notebook model and default |
| `openai/gpt-oss-20b` | Smaller, faster alternative |
| `llama-3.3-70b-versatile` | 70B alternative |

All three currently appear in Groq's tool-use model list. Model availability can change; check Groq's model page if a model ID stops working.

## Setup

Python 3.10 or newer is recommended.

```bash
python -m venv .venv
```

Activate the environment, then install dependencies:

```bash
python -m pip install -r requirements.txt
python -m pip install -e .
```

Copy `.env.example` to `.env` and add your own API keys. Do not commit `.env` or paste API keys into source files. In Google Colab, store keys in Colab Secrets and expose them as environment variables before importing the package.

Required keys: `GROQ_API_KEY`, `TAVILY_API_KEY`.

## Run

```bash
python -m research_agent "What are the main approaches to quantum error correction?"
```

Choose a model for one run:

```bash
GROQ_MODEL=llama-3.3-70b-versatile python -m research_agent "Your research question"
```

On PowerShell, set the environment variable first with `$env:GROQ_MODEL = "llama-3.3-70b-versatile"`.

The agent has four tools:

1. `web_search` — searches the web with Tavily.
2. `arxiv_academic_search` — searches ArXiv.
3. `wikipedia_search` — gets background summaries.
4. `read_webpage` — fetches and reads a supplied public HTTP(S) URL. This is a page reader, not a search tool.

For better grounding, the agent is instructed to inspect primary sources when available, distinguish publication dates from event dates, support claims with source URLs, and say when evidence is missing or conflicting. Search snippets alone should not be treated as verified evidence.

## Google Colab

Upload and extract the project ZIP into `/content/research-agent`, then open `research_agent_colab.ipynb` in Colab. The notebook installs dependencies and reads API keys from Colab Secrets. Alternatively, run the CLI from a terminal in the project root.

## Notes

- The URL reader only accepts public HTTP(S) URLs, limits redirects and download size, and extracts readable page text. Some sites block automated access or render content in JavaScript; those pages may not be readable.
- The agent's citations are generated from source material returned by tools. Review important claims and references before relying on a report.
- This project intentionally contains no API credentials.
