"""Command line entry point."""

import argparse

from .agent import run_research
from .config import get_model_name


def main():
    parser = argparse.ArgumentParser(description="Research a question with sources.")
    parser.add_argument("query", nargs="+", help="Research question")
    args = parser.parse_args()
    print(f"Using Groq model: {get_model_name()}\n")
    print(run_research(" ".join(args.query)))


if __name__ == "__main__":
    main()
