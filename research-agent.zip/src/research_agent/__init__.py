"""Configurable research agent."""

from .agent import build_agent, run_research

__all__ = ["build_agent", "run_research"]
