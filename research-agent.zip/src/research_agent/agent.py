"""Agent construction and research entry point."""

import os

from langchain.agents import create_agent
from langchain_groq import ChatGroq

from .config import get_max_steps, get_model_name
from .prompts import SYSTEM_PROMPT
from .tools import get_tools


def build_agent():
    if not os.getenv("GROQ_API_KEY"):
        raise RuntimeError("Set GROQ_API_KEY in the environment or in your .env file first.")
    if not os.getenv("TAVILY_API_KEY"):
        raise RuntimeError("Set TAVILY_API_KEY in the environment or in your .env file first.")

    model_name = get_model_name()
    options = {"model": model_name, "temperature": 0.2, "max_tokens": 4096}
    # Groq exposes reasoning_effort for its GPT-OSS models; leave it unset for Llama.
    if model_name.startswith("openai/gpt-oss-"):
        options["reasoning_effort"] = "low"
    model = ChatGroq(**options)
    return create_agent(model=model, tools=get_tools(), system_prompt=SYSTEM_PROMPT)


def run_research(query: str) -> str:
    """Run the research agent and return its final answer text."""
    if not query or not query.strip():
        raise ValueError("Research query cannot be empty.")
    agent = build_agent()
    result = agent.invoke(
        {"messages": [{"role": "user", "content": query.strip()}]},
        config={"recursion_limit": get_max_steps()},
    )
    message = result["messages"][-1]
    return str(message.content)
