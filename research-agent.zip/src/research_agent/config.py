"""Application configuration loaded from environment variables."""

import os

from dotenv import load_dotenv

load_dotenv()

DEFAULT_MODEL = "openai/gpt-oss-120b"
SUPPORTED_MODELS = {
    DEFAULT_MODEL,
    "openai/gpt-oss-20b",
    "llama-3.3-70b-versatile",
}


def get_model_name() -> str:
    name = os.getenv("GROQ_MODEL", DEFAULT_MODEL).strip()
    if name not in SUPPORTED_MODELS:
        choices = ", ".join(sorted(SUPPORTED_MODELS))
        raise ValueError(f"Unsupported GROQ_MODEL {name!r}. Choose one of: {choices}")
    return name


def get_max_steps() -> int:
    try:
        value = int(os.getenv("MAX_STEPS", "20"))
    except ValueError as exc:
        raise ValueError("MAX_STEPS must be a positive integer") from exc
    if value < 1:
        raise ValueError("MAX_STEPS must be a positive integer")
    return value
