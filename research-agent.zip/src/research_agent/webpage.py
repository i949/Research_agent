"""Bounded, public-web-only page reader used as a non-search research tool."""

from __future__ import annotations

import ipaddress
import socket
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

MAX_BYTES = 1_000_000
MAX_REDIRECTS = 4
USER_AGENT = "ResearchAgent/1.0 (source reading; contact: local notebook user)"


def _validate_public_url(url: str) -> None:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("Only absolute HTTP or HTTPS URLs are supported.")
    if parsed.username or parsed.password:
        raise ValueError("URLs containing credentials are not allowed.")
    host = parsed.hostname.rstrip(".").lower()
    if host == "localhost" or host.endswith((".localhost", ".local", ".internal")):
        raise ValueError("Private and local network hosts are not allowed.")
    try:
        addresses = {ipaddress.ip_address(host)}
    except ValueError:
        try:
            addresses = {
                ipaddress.ip_address(item[4][0])
                for item in socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme == "https" else 80))
            }
        except socket.gaierror as exc:
            raise ValueError("The URL host could not be resolved.") from exc
    if not addresses or any(not address.is_global for address in addresses):
        raise ValueError("Private and local network hosts are not allowed.")


def read_public_webpage(url: str) -> str:
    """Read up to 1 MB from a public HTML or text page, following few redirects."""
    current_url = url.strip()
    session = requests.Session()
    session.headers.update({"User-Agent": USER_AGENT, "Accept": "text/html,text/plain;q=0.9,*/*;q=0.1"})
    try:
        for _ in range(MAX_REDIRECTS + 1):
            _validate_public_url(current_url)
            response = session.get(
                current_url,
                timeout=(5, 15),
                allow_redirects=False,
                stream=True,
            )
            if response.is_redirect or response.is_permanent_redirect:
                location = response.headers.get("Location")
                response.close()
                if not location:
                    return "The page returned a redirect without a destination."
                current_url = urljoin(current_url, location)
                continue
            response.raise_for_status()
            content_type = response.headers.get("Content-Type", "").lower()
            if not any(kind in content_type for kind in ("text/html", "text/plain", "application/xhtml+xml")):
                response.close()
                return f"Page not read: unsupported content type {content_type or '(unknown)'}."
            chunks: list[bytes] = []
            size = 0
            for chunk in response.iter_content(chunk_size=16_384):
                size += len(chunk)
                if size > MAX_BYTES:
                    response.close()
                    return f"Page was larger than the {MAX_BYTES:,}-byte reading limit; only a smaller page can be inspected."
                chunks.append(chunk)
            encoding = response.encoding or "utf-8"
            html = b"".join(chunks).decode(encoding, errors="replace")
            response.close()
            if "text/plain" in content_type:
                text = html
                title = current_url
            else:
                soup = BeautifulSoup(html, "html.parser")
                title = soup.title.get_text(" ", strip=True) if soup.title else current_url
                for element in soup(["script", "style", "noscript", "svg", "nav", "footer", "form"]):
                    element.decompose()
                root = soup.find("main") or soup.find("article") or soup.body or soup
                text = root.get_text(" ", strip=True)
            text = " ".join(text.split())
            if not text:
                return f"No readable text was found at {current_url}. The site may require JavaScript or sign-in."
            return f"Title: {title}\nURL: {current_url}\nExtracted text (up to 10,000 chars):\n{text[:10_000]}"
        return "The page exceeded the redirect limit and was not read."
    except (requests.RequestException, ValueError) as exc:
        return f"Could not read {current_url}: {exc}"
    finally:
        session.close()
