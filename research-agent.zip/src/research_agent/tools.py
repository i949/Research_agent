"""Research tools: three search sources plus a direct page reader."""

import json
import xml.etree.ElementTree as ET

import requests
from langchain_core.tools import tool
from langchain_tavily import TavilySearch

from .webpage import read_public_webpage

_tavily = TavilySearch(
    max_results=5,
    topic="general",
    auto_parameters=True,
    include_answer=False,
    include_raw_content=False,
)
_ARXIV_NS = {"atom": "http://www.w3.org/2005/Atom"}
_USER_AGENT = "ResearchAgent/1.0 (academic research helper)"


@tool
def web_search(query: str) -> str:
    """Search the web for recent reporting, primary sources, and official material. Use focused queries."""
    try:
        raw = _tavily.invoke({"query": query})
        if isinstance(raw, dict):
            records = raw.get("results", [])
        elif isinstance(raw, list):
            records = raw
        else:
            records = [raw]
        unique = []
        seen_urls = set()
        for item in records:
            if not isinstance(item, dict):
                unique.append(str(item))
                continue
            url = item.get("url", "")
            if url and url in seen_urls:
                continue
            if url:
                seen_urls.add(url)
            unique.append({
                key: item.get(key)
                for key in ("title", "url", "published_date", "content", "score")
                if item.get(key) is not None
            })
        return json.dumps(unique, ensure_ascii=False, indent=2) if unique else "No results were returned."
    except Exception as exc:
        return f"Web search failed: {type(exc).__name__}: {exc}"


@tool("arxiv_academic_search")
def arxiv_search(query: str) -> str:
    """Search ArXiv for scientific papers and preprints relevant to a research question."""
    params = {
        "search_query": f"all:{query}",
        "start": 0,
        "max_results": 3,
        "sortBy": "relevance",
        "sortOrder": "descending",
    }
    try:
        response = requests.get(
            "https://export.arxiv.org/api/query",
            params=params,
            headers={"User-Agent": _USER_AGENT},
            timeout=(5, 20),
        )
        response.raise_for_status()
        root = ET.fromstring(response.content)
        papers = []
        for entry in root.findall("atom:entry", _ARXIV_NS):
            authors = [node.text for node in entry.findall("atom:author/atom:name", _ARXIV_NS) if node.text]
            papers.append({
                "title": " ".join((entry.findtext("atom:title", default="", namespaces=_ARXIV_NS)).split()),
                "authors": authors,
                "published": entry.findtext("atom:published", default="", namespaces=_ARXIV_NS),
                "url": entry.findtext("atom:id", default="", namespaces=_ARXIV_NS),
                "abstract": " ".join((entry.findtext("atom:summary", default="", namespaces=_ARXIV_NS)).split()),
            })
        return json.dumps(papers, ensure_ascii=False, indent=2) if papers else "ArXiv returned no matching papers."
    except (requests.RequestException, ET.ParseError) as exc:
        return f"ArXiv search failed: {type(exc).__name__}: {exc}"


@tool("wikipedia_search")
def wikipedia_search(query: str) -> str:
    """Find concise Wikipedia background summaries. Do not use as the only source for recent or disputed claims."""
    params = {
        "action": "query",
        "generator": "search",
        "gsrsearch": query,
        "gsrlimit": 2,
        "prop": "extracts|info",
        "exintro": 1,
        "explaintext": 1,
        "inprop": "url",
        "format": "json",
    }
    try:
        response = requests.get(
            "https://en.wikipedia.org/w/api.php",
            params=params,
            headers={"User-Agent": _USER_AGENT},
            timeout=(5, 15),
        )
        response.raise_for_status()
        payload = response.json()
        pages = payload.get("query", {}).get("pages", {})
        results = [
            {key: page.get(key) for key in ("title", "fullurl", "extract") if page.get(key)}
            for page in sorted(pages.values(), key=lambda item: item.get("index", 0))
        ]
        return json.dumps(results, ensure_ascii=False, indent=2) if results else "Wikipedia returned no matching pages."
    except (requests.RequestException, ValueError) as exc:
        return f"Wikipedia search failed: {type(exc).__name__}: {exc}"


@tool("read_webpage")
def read_webpage_tool(url: str) -> str:
    """Read the text of one public webpage when you already have its URL. This tool does not search."""
    return read_public_webpage(url)


def get_tools():
    """Return the three search tools and one direct page-reading tool."""
    return [web_search, arxiv_search, wikipedia_search, read_webpage_tool]
